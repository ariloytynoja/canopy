Canopy
======

Parallelised iterative search of optimal phylogeny and phylogeny-aware sequence alignment

The tool was developed in Loytynoja's group:http://loytynojalab.biocenter.helsinki.fi.

The detailed installation and usage instructions can be found in http://wasabiapp.org/software/canopy.
