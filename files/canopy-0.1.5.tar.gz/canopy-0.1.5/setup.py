import glob, sys, os
from setuptools import setup
import canopy

target_dir = canopy.global_path
make_symlink = False
if '--user' in sys.argv:
        target_dir = os.path.expanduser(canopy.local_path)
        make_symlink = True

source_dir = os.path.join(canopy.package_name, canopy.bin_path)
target_dir += canopy.bin_path
extend_files = {target_dir:[]}

def walk_dir(sdir, tdir):
        for f in glob.glob(os.path.join(sdir, '*')):
                if os.path.isfile(f):
                        extend_files.setdefault(tdir, []).append(f)
                else:
                        subdir = os.path.relpath(f, sdir)
                        ntdir = os.path.join(tdir, subdir)
                        walk_dir(f, ntdir)
walk_dir(source_dir, target_dir)

setup(name=canopy.package_name,
      version=canopy.__version__,
      description='Co-estimation alignment and phylogeny in Python',
      author='Chunxiang Li',
      url='http://wasabiapp.org/software/canopy',
      license='GNU GENERAL PUBLIC LICENSE Version 3(http://www.gnu.org/licenses/)',
      author_email='chunxiang.li@helsinki.fi',
      platforms=['*nix', 'Darwin'],
      install_requires=['Dendropy==3.10.0', 'Biopython==1.58', 'NumPy==1.14.0'],
      packages=[canopy.package_name],
      package_data={ '':['setup_virtualenv', 'LICENSE'],
		     'example': ['example.cfg', 'example.fas'],
		     'example/multilocus':['gene1.txt', 'gene2.txt'],
		     'canopy': ['README'],
		     'canopy/mac_bin':['*'],
		     'canopy/bin':['*']},
      data_files= sorted(extend_files.items()),
      scripts=['scripts/'+canopy.package_name, 'scripts/wasabi']
     )

if make_symlink:
        bin_path = os.environ['PATH'].split(':')[0]
        symlink_path = os.path.join(bin_path, canopy.package_name)
        install_path = os.path.expanduser(canopy.local_path)
        try:
                os.symlink(install_path, os.path.join(bin_path, canopy.package_name))
        except:
                print "Cannot add Canopy to PATH ("+bin_path+")!\nYou can find Canopy from "+install_path
